/*
  Projet serveur Web - reseau.c
  Fonctions r�seau
*/

#include <sys/types.h>
#include <sys/errno.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <netinet/in.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>

#include "declarations.h"

/* ------------------------------------------------------------
  Fonctions r�seau
------------------------------------------------------------ */

int serveur_tcp (int numero_port)
{
  int fd;

  /* d�marre un service TCP sur le port indiqu� */

  struct sockaddr_in addr_serveur;
  size_t lg_addr_serveur = sizeof addr_serveur;

  //TODO 1:  cr�ation de la prise : http://pubs.opengroup.org/onlinepubs/000095399/functions/socket.html
  // r�cup�ration du descripteur dans fd et test de la bonne r�alisation (FATAL)
   
  //FIN TODO
  
  /* nommage de la prise */
  addr_serveur.sin_family      = AF_INET;
  addr_serveur.sin_addr.s_addr = INADDR_ANY;
  addr_serveur.sin_port        = htons(numero_port);
  
  
  // TODO 2: associer un nom � la socket : http://pubs.opengroup.org/onlinepubs/000095399/functions/bind.html
  //  et test de la bonne r�allisation (FATAL)
 
  //FIN TODO

  // TODO 3: ouverture du service http://pubs.opengroup.org/onlinepubs/000095399/functions/listen.html. 
  // backlog de 4 
  
  // FIN TODO
  
  return (fd);
}

int attendre_client(int fd_serveur)
{
  int fd_client;
  /* A cause des signaux SIGCHLD, la fonction accept()
     peut etre interrompue quand un fils se termine.
     Dans ce cas, on relance accept().
  */
  while ( (fd_client = accept(fd_serveur, NULL, NULL)) < 0) { // http://pubs.opengroup.org/onlinepubs/000095399/functions/accept.html
    if (errno != EINTR)
      FATAL("Fin anormale de accept().");
  }
  return(fd_client);
}
